# Blinkit Excel Dashboard

## Project Overview
This project is an interactive Excel dashboard built using Blinkit grocery sales data. The main purpose of this project is to convert raw sales data into clear business insights using Excel. Instead of reading large tables, users can understand sales performance, customer preferences, and outlet performance through charts, KPI cards, and filters.

## Objective
The objective of this project is to analyze Blinkit grocery sales data and create an interactive dashboard that helps users:
- Track overall sales performance
- Understand customer buying patterns
- Compare outlet performance
- Identify top-selling product categories
- Support better business decision-making

## Tools Used
- Microsoft Excel
- Pivot Tables
- Pivot Charts
- KPI Cards
- Slicers / Filters
- Data Cleaning
- Formulas and Functions

## Dashboard Preview
### Dashboard Overview
![Dashboard Overview](images/dashboard_overview.png)

### Presentation Preview
![Presentation Preview](images/presentation_preview.png)

### Key Insights Page
![Key Insights](images/key_insights_page.png)

## Key Features
The dashboard includes the following main features:
- Total Sales
- Average Sales
- Number of Items Sold
- Average Customer Rating
- Sales by Outlet Establishment Year
- Sales by Fat Content
- Sales by Item Type
- Sales by Outlet Size
- Sales by Outlet Location
- Sales by Outlet Type

## Project Workflow
### 1. Data Collection
The Blinkit grocery sales dataset was used as the main data source for this project.

### 2. Data Cleaning
The raw data was cleaned in Excel by:
- Removing duplicates
- Checking missing values
- Standardizing text values
- Making sure number formats were correct

### 3. Data Analysis
The cleaned data was analyzed using Pivot Tables and formulas to calculate important KPIs and compare different categories.

### 4. Dashboard Creation
An interactive dashboard was created using charts, cards, and slicers so that users can easily explore the data.

## How to Use
1. Download or clone this repository.
2. Open the Excel workbook in Microsoft Excel desktop version.
3. Open the dashboard sheet to view the visual analysis.
4. Use the filters or slicers to check performance by outlet size, outlet location, and item type.
5. Review KPI cards such as total sales, average sales, number of items sold, and average rating.
6. Use the charts to compare sales by category, fat content, outlet type, and location.
7. Refresh the workbook if needed by clicking **Data > Refresh All** in Excel.

## Main Insights
Some important findings from the project are:
- Total sales were around **$1.20M**
- Average sales were **$141**
- Total number of items sold was **8,523**
- Average customer rating was **4.0**
- Fruits and Vegetables and Snack Foods were among the top-selling categories
- Regular fat products contributed more sales than low-fat products
- High-size outlets performed better than small outlets
- Tier 1 locations generated the highest sales
- Supermarket Type 1 contributed the highest revenue among outlet types

## Business Value
This dashboard helps businesses in:
- Monitoring sales performance quickly
- Identifying strong and weak outlet types
- Understanding customer product preferences
- Improving inventory and promotion planning
- Making data-driven decisions

## Files Included
This repository may include:
- Excel Dashboard File
- Source Dataset
- Project Documentation PDF
- Presentation File
- Dashboard Screenshots

## Recommended Repository Structure
```text
blinkit_excel_dashboard/
│
├── README.md
├── data/
│   └── BlinkIT Grocery Data Excel.xlsx
├── dashboard/
│   └── BlinkIT_Interactive_Dashboard_With_Guide.xlsx
├── docs/
│   └── Blinkit Grocery Sales Analysis Documentation.pdf
├── presentation/
│   └── Blinkit_Grocery_Sales_Presentation.pptx
└── images/
    ├── dashboard_overview.png
    ├── presentation_preview.png
    └── key_insights_page.png
```

## Conclusion
This project shows how Excel can be used not only for storing data but also for analyzing and presenting business insights in an interactive way. It helped improve skills in Excel, data analysis, dashboard design, and business understanding.

## Author
**Manav Malhotra**
